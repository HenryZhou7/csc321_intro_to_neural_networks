See http://www.cs.toronto.edu/~yaojian/csc321/assignment1.html



